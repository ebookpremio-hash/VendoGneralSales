package com.vendogneral.sales

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

// Set these to your deployed HTTPS backend and matching APP_API_TOKEN.
private const val API_BASE_URL = "https://YOUR-HTTPS-BACKEND.example"
private const val APP_TOKEN = "REPLACE_WITH_APP_API_TOKEN"
private val http = OkHttpClient()
private val jsonType = "application/json; charset=utf-8".toMediaType()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { MainScreen() } }
    }
}
private data class Metric(val title: String, val revenue: Double, val orders: Int)
private data class Product(val id: Long, val name: String, val price: Double, val sku: String, val stock: Int?, val stockStatus: String, val manageStock: Boolean)
private data class ApiResult(val code: Int, val body: String)

private suspend fun api(path: String, method: String = "GET", payload: JSONObject? = null): JSONObject = withContext(Dispatchers.IO) {
    val builder = Request.Builder().url(API_BASE_URL.trimEnd('/') + path).header("Authorization", "Bearer $APP_TOKEN")
    when (method) {
        "POST" -> builder.post((payload ?: JSONObject()).toString().toRequestBody(jsonType))
        "PUT" -> builder.put((payload ?: JSONObject()).toString().toRequestBody(jsonType))
        "DELETE" -> builder.delete()
        else -> builder.get()
    }
    http.newCall(builder.build()).execute().use { response ->
        val text = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException(runCatching { JSONObject(text).optString("error") }.getOrDefault("HTTP ${response.code}"))
        JSONObject(text)
    }
}

@Composable
private fun MainScreen() {
    var tab by remember { mutableIntStateOf(0) }
    val purple = Color(0xFF4F2ACB)
    Scaffold(topBar = {
        Surface(color = purple) { Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text("VendoGneral Sales", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("إدارة المبيعات والمنتجات", color = Color.White)
        } }
    }, bottomBar = {
        NavigationBar {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("📊") }, label = { Text("المبيعات") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("🛍️") }, label = { Text("المنتجات") })
        }
    }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (tab == 0) DashboardScreen() else ProductsScreen()
        }
    }
}

@Composable
private fun DashboardScreen() {
    var metrics by remember { mutableStateOf<List<Metric>>(emptyList()) }
    var message by remember { mutableStateOf("اضغط تحديث لجلب بيانات متجرك") }
    var loading by remember { mutableStateOf(false) }
    val purple = Color(0xFF4F2ACB); val orange = Color(0xFFFF8A00); val scope = rememberCoroutineScope()
    fun refresh() { scope.launch {
        loading = true; message = "جارٍ الاتصال بالخادم..."
        try {
            val json = api("/api/dashboard"); val m = json.getJSONObject("metrics")
            metrics = listOf(Metric("مبيعات اليوم",m.getJSONObject("today").getDouble("revenue"),m.getJSONObject("today").getInt("orders")),Metric("مبيعات الأسبوع",m.getJSONObject("week").getDouble("revenue"),m.getJSONObject("week").getInt("orders")),Metric("مبيعات الشهر",m.getJSONObject("month").getDouble("revenue"),m.getJSONObject("month").getInt("orders")),Metric("مبيعات السنة",m.getJSONObject("year").getDouble("revenue"),m.getJSONObject("year").getInt("orders")))
            message = "آخر تحديث: ${json.optString("updatedAt")}"
        } catch (e: Exception) { message = e.message ?: "تعذر الاتصال. تحقق من إعدادات الخادم." } finally { loading = false }
    } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("ملخص المبيعات", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(message, fontSize = 12.sp, color = Color.Gray) }
        if (metrics.isEmpty()) item { Card { Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ستظهر بيانات WooCommerce هنا"); Spacer(Modifier.height(10.dp))
            Button(enabled = !loading, onClick = { refresh() }, colors = ButtonDefaults.buttonColors(containerColor = orange)) { Text(if (loading) "جارٍ التحديث..." else "تحديث البيانات") }
        } } } else {
            items(metrics) { metric -> Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F5FF))) { Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text(metric.title, color = purple, fontWeight = FontWeight.SemiBold); Text(euro(metric.revenue), fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("عدد الطلبات: ${metric.orders}", color = Color.DarkGray)
            } } }
            item { Button(onClick = { refresh() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = orange)) { Text(if (loading) "جارٍ التحديث..." else "تحديث البيانات") } }
        }
    }
}

@Composable
private fun ProductsScreen() {
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("حمّل المنتجات من متجرك") }
    var search by remember { mutableStateOf("") }
    var editor by remember { mutableStateOf<Product?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Product?>(null) }
    fun load(query: String = search) { scope.launch {
        loading = true
        try {
            val suffix = if (query.isBlank()) "" else "?search=" + java.net.URLEncoder.encode(query, "UTF-8")
            val result = api("/api/products$suffix"); val arr = result.optJSONArray("products") ?: JSONArray()
            products = (0 until arr.length()).map { i -> arr.getJSONObject(i).toProduct() }
            message = "عدد المنتجات المعروضة: ${products.size}"
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل المنتجات" } finally { loading = false }
    } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("إدارة المنتجات", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), label = { Text("ابحث عن منتج") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !loading, onClick = { load() }, modifier = Modifier.weight(1f)) { Text(if (loading) "جارٍ التحميل..." else "عرض / تحديث") }
            Button(onClick = { editor = null; showEditor = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8A00))) { Text("+ منتج جديد") }
        }
        Text(message, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(products, key = { it.id }) { p ->
                Card { Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text(p.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("السعر: ${euro(p.price)}")
                    Text("SKU: ${p.sku.ifBlank { "—" }}")
                    Text(if (p.manageStock) "المخزون: ${p.stock ?: 0}" else "المخزون: غير مُدار")
                    Text(if (p.stockStatus == "instock") "الحالة: متوفر" else "الحالة: ${p.stockStatus}", color = if (p.stockStatus == "instock") Color(0xFF16803C) else Color.Red)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { editor = p; showEditor = true }, modifier = Modifier.weight(1f)) { Text("تعديل") }
                        OutlinedButton(onClick = { deleting = p }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red)) { Text("حذف") }
                    }
                } }
            }
        }
    }
    if (showEditor) ProductEditorDialog(initial = editor, onDismiss = { showEditor = false }, onSave = { payload ->
        scope.launch {
            try {
                val current = editor
                api(if (current == null) "/api/products" else "/api/products/${current.id}", if (current == null) "POST" else "PUT", payload)
                showEditor = false; load()
            } catch (e: Exception) { message = e.message ?: "فشل حفظ المنتج" }
        }
    })
    deleting?.let { p -> AlertDialog(onDismissRequest = { deleting = null }, title = { Text("حذف المنتج؟") }, text = { Text("سيتم حذف «${p.name}» نهائياً من المتجر.") }, confirmButton = { TextButton(onClick = {
        scope.launch { try { api("/api/products/${p.id}", "DELETE"); deleting = null; load() } catch (e: Exception) { message = e.message ?: "فشل الحذف"; deleting = null } }
    }) { Text("حذف نهائياً", color = Color.Red) } }, dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء") } }) }
}

@Composable
private fun ProductEditorDialog(initial: Product?, onDismiss: () -> Unit, onSave: (JSONObject) -> Unit) {
    var name by remember(initial) { mutableStateOf(initial?.name ?: "") }
    var price by remember(initial) { mutableStateOf(if (initial == null) "" else initial.price.toString()) }
    var stock by remember(initial) { mutableStateOf(initial?.stock?.toString() ?: "0") }
    var sku by remember(initial) { mutableStateOf(initial?.sku ?: "") }
    var manageStock by remember(initial) { mutableStateOf(initial?.manageStock ?: true) }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initial == null) "إضافة منتج" else "تعديل المنتج") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("اسم المنتج *") }, singleLine = true)
            OutlinedTextField(price, { price = it }, label = { Text("السعر باليورو *") }, singleLine = true)
            OutlinedTextField(sku, { sku = it }, label = { Text("رمز SKU") }, singleLine = true)
            OutlinedTextField(stock, { stock = it }, label = { Text("الكمية في المخزون") }, singleLine = true, enabled = manageStock)
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = manageStock, onCheckedChange = { manageStock = it }); Text("تتبّع المخزون") }
            if (error.isNotBlank()) Text(error, color = Color.Red)
        }
    }, confirmButton = { TextButton(onClick = {
        val amount = price.replace(',', '.').toDoubleOrNull()
        val quantity = stock.toIntOrNull()
        if (name.isBlank()) error = "اسم المنتج مطلوب"
        else if (amount == null || amount < 0) error = "أدخل سعراً صحيحاً"
        else if (manageStock && (quantity == null || quantity < 0)) error = "أدخل كمية صحيحة"
        else { val payload = JSONObject().put("name", name.trim()).put("regularPrice", amount.toString()).put("sku", sku.trim()).put("manageStock", manageStock).put("status", "publish"); if (manageStock) payload.put("stockQuantity", quantity); onSave(payload) }
    }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

private fun JSONObject.toProduct() = Product(optLong("id"), optString("name"), optDouble("price"), optString("sku"), if (isNull("stockQuantity")) null else optInt("stockQuantity"), optString("stockStatus", "instock"), optBoolean("manageStock"))
private fun euro(amount: Double): String = NumberFormat.getCurrencyInstance(Locale.GERMANY).format(amount)
