'use strict';
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const axios = require('axios');
const crypto = require('crypto');
const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({ limit: '20kb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }));
const { STORE_URL, WC_CONSUMER_KEY, WC_CONSUMER_SECRET, APP_API_TOKEN } = process.env;
const PORT = Number(process.env.PORT || 8080);
function requireConfig() {
  const vars = { STORE_URL, WC_CONSUMER_KEY, WC_CONSUMER_SECRET, APP_API_TOKEN };
  const missing = Object.entries(vars).filter(([k,v]) => !v || String(v).includes('replace_me')).map(([k]) => k);
  if (missing.length) throw new Error('Missing environment variables: ' + missing.join(', '));
}
function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  const a = Buffer.from(token); const b = Buffer.from(APP_API_TOKEN || 'not-configured');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({error:'Unauthorized'});
  next();
}
const dayStart = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const weekStart = d => { const x = dayStart(d); x.setDate(x.getDate() - ((x.getDay()+6)%7)); return x; };
const monthStart = d => new Date(d.getFullYear(), d.getMonth(), 1);
const yearStart = d => new Date(d.getFullYear(), 0, 1);
const round2 = n => Math.round((n + Number.EPSILON) * 100) / 100;
async function fetchOrders(after) {
  const api = axios.create({
    baseURL: STORE_URL.replace(/\/+$/, '') + '/wp-json/wc/v3',
    timeout: 20000,
    auth: { username: WC_CONSUMER_KEY, password: WC_CONSUMER_SECRET },
    headers: { Accept: 'application/json' }
  });
  let all = [];
  for (let page=1; page<=10; page++) {
    const response = await api.get('/orders', { params: {
      after: after.toISOString(), before: new Date().toISOString(), per_page: 100, page,
      orderby: 'date', order: 'desc', status: 'processing,completed'
    }});
    const rows = Array.isArray(response.data) ? response.data : [];
    all = all.concat(rows);
    if (rows.length < 100) break;
  }
  return all;
}
function inRange(order, from, to) {
  const raw = order.date_created_gmt || order.date_created;
  const d = new Date(raw);
  return d >= from && d < to;
}
function summarize(orders, from, to) {
  const rows = orders.filter(o => inRange(o, from, to));
  return { revenue: round2(rows.reduce((sum,o) => sum + Number(o.total || 0), 0)), orders: rows.length };
}
app.get('/health', (_req,res) => res.json({ok:true, service:'VendoGneral Sales API'}));
app.get('/api/dashboard', auth, async (_req,res) => {
  try {
    requireConfig();
    const now = new Date();
    const orders = await fetchOrders(yearStart(now));
    const paid = orders.filter(o => ['processing','completed'].includes(o.status));
    const end = new Date(now.getTime()+1);
    const products = new Map();
    for (const order of paid) for (const item of (order.line_items || [])) {
      const key = String(item.product_id || item.name);
      const p = products.get(key) || { productId:item.product_id, name:item.name, quantity:0, revenue:0 };
      p.quantity += Number(item.quantity || 0); p.revenue += Number(item.total || 0); products.set(key,p);
    }
    res.json({
      currency:'EUR', updatedAt:now.toISOString(),
      metrics:{ today:summarize(paid,dayStart(now),end), week:summarize(paid,weekStart(now),end), month:summarize(paid,monthStart(now),end), year:summarize(paid,yearStart(now),end) },
      topProducts:[...products.values()].map(p=>({...p,revenue:round2(p.revenue)})).sort((a,b)=>b.quantity-a.quantity).slice(0,5),
      note:'الإيرادات هي مجموع الطلبات قيد المعالجة والمكتملة وليست الربح الصافي.'
    });
  } catch (e) {
    console.error('Dashboard error:', e.response?.status || e.message);
    res.status(502).json({error:'تعذر جلب بيانات WooCommerce. تحقق من إعدادات الخادم ومفتاح القراءة.'});
  }
});

function wcApi() {
  return axios.create({
    baseURL: STORE_URL.replace(/\/+$/, '') + '/wp-json/wc/v3',
    timeout: 20000,
    auth: { username: WC_CONSUMER_KEY, password: WC_CONSUMER_SECRET },
    headers: { Accept: 'application/json' }
  });
}
function safeProduct(p) {
  return {
    id: p.id, name: p.name, sku: p.sku || '',
    price: Number(p.price || p.regular_price || 0),
    regularPrice: p.regular_price || '', salePrice: p.sale_price || '',
    stockQuantity: p.stock_quantity == null ? null : Number(p.stock_quantity),
    stockStatus: p.stock_status || 'instock', manageStock: Boolean(p.manage_stock),
    status: p.status || 'publish', image: p.images?.[0]?.src || '',
    permalink: p.permalink || ''
  };
}
app.get('/api/products', auth, async (req, res) => {
  try {
    requireConfig();
    const page = Math.max(1, Math.min(100, Number.parseInt(req.query.page || '1', 10) || 1));
    const params = { page, per_page: 50, orderby: 'date', order: 'desc' };
    if (req.query.search) params.search = String(req.query.search).slice(0, 100);
    const response = await wcApi().get('/products', { params });
    res.json({ products: response.data.map(safeProduct), page, totalPages: Number(response.headers['x-wp-totalpages'] || 1), total: Number(response.headers['x-wp-total'] || response.data.length) });
  } catch (e) {
    console.error('Products list error:', e.response?.status || e.message);
    res.status(502).json({ error: 'تعذر جلب المنتجات من WooCommerce. تحقق من إعدادات الخادم وصلاحيات مفاتيح API.' });
  }
});
app.post('/api/products', auth, async (req, res) => {
  try {
    requireConfig();
    const { name, regularPrice, stockQuantity, manageStock = true, sku = '', status = 'publish' } = req.body || {};
    if (typeof name !== 'string' || !name.trim()) return res.status(400).json({ error: 'اسم المنتج مطلوب.' });
    if (regularPrice === undefined || regularPrice === '' || !Number.isFinite(Number(regularPrice)) || Number(regularPrice) < 0) return res.status(400).json({ error: 'أدخل سعراً صحيحاً.' });
    const payload = { name: name.trim(), regular_price: String(regularPrice), sku: String(sku).trim(), manage_stock: Boolean(manageStock), status: ['publish','draft','private'].includes(status) ? status : 'publish' };
    if (payload.manage_stock && stockQuantity !== '' && stockQuantity != null) {
      if (!Number.isInteger(Number(stockQuantity)) || Number(stockQuantity) < 0) return res.status(400).json({ error: 'كمية المخزون يجب أن تكون عدداً صحيحاً غير سالب.' });
      payload.stock_quantity = Number(stockQuantity);
    }
    const response = await wcApi().post('/products', payload);
    res.status(201).json({ product: safeProduct(response.data) });
  } catch (e) {
    console.error('Product create error:', e.response?.status || e.message);
    res.status(e.response?.status === 400 ? 400 : 502).json({ error: e.response?.data?.message || 'تعذر إنشاء المنتج. تحقق من البيانات وصلاحيات WooCommerce.' });
  }
});
app.put('/api/products/:id', auth, async (req, res) => {
  try {
    requireConfig();
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'معرّف المنتج غير صحيح.' });
    const { name, regularPrice, stockQuantity, manageStock = true, sku = '', status = 'publish' } = req.body || {};
    if (typeof name !== 'string' || !name.trim()) return res.status(400).json({ error: 'اسم المنتج مطلوب.' });
    if (regularPrice === undefined || regularPrice === '' || !Number.isFinite(Number(regularPrice)) || Number(regularPrice) < 0) return res.status(400).json({ error: 'أدخل سعراً صحيحاً.' });
    const payload = { name: name.trim(), regular_price: String(regularPrice), sku: String(sku).trim(), manage_stock: Boolean(manageStock), status: ['publish','draft','private'].includes(status) ? status : 'publish' };
    if (payload.manage_stock && stockQuantity !== '' && stockQuantity != null) {
      if (!Number.isInteger(Number(stockQuantity)) || Number(stockQuantity) < 0) return res.status(400).json({ error: 'كمية المخزون يجب أن تكون عدداً صحيحاً غير سالب.' });
      payload.stock_quantity = Number(stockQuantity);
    }
    const response = await wcApi().put(`/products/${id}`, payload);
    res.json({ product: safeProduct(response.data) });
  } catch (e) {
    console.error('Product update error:', e.response?.status || e.message);
    res.status(e.response?.status === 400 ? 400 : 502).json({ error: e.response?.data?.message || 'تعذر تعديل المنتج. تحقق من البيانات وصلاحيات WooCommerce.' });
  }
});
app.delete('/api/products/:id', auth, async (req, res) => {
  try {
    requireConfig();
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'معرّف المنتج غير صحيح.' });
    const response = await wcApi().delete(`/products/${id}`, { params: { force: true } });
    res.json({ deleted: true, id: response.data.id });
  } catch (e) {
    console.error('Product delete error:', e.response?.status || e.message);
    res.status(502).json({ error: e.response?.data?.message || 'تعذر حذف المنتج. تحقق من صلاحيات WooCommerce.' });
  }
});

app.use((_req,res)=>res.status(404).json({error:'Not found'}));
try { requireConfig(); app.listen(PORT,()=>console.log(`VendoGneral Sales API listening on ${PORT}`)); }
catch(e) { console.error(e.message); process.exit(1); }
